#ifndef COGNOSCO_FILES_COGNOSCO_CORE_H_
#define COGNOSCO_FILES_COGNOSCO_CORE_H_
namespace cognosco {}
#endif
