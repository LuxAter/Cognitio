#ifndef COGNOSCO_FILES_GENETIC_ALGORITHM_GENETIC_CORE_H_
#define COGNOSCO_FILES_GENETIC_ALGORITHM_GENETIC_CORE_H_
namespace cognosco {
namespace genetic {}
}
#endif
